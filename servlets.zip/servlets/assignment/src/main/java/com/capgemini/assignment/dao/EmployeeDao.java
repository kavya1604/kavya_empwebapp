package com.capgemini.assignment.dao;


import java.util.List;

import com.capgemini.assignment.dto.Employee;

public interface EmployeeDao {
	  public Employee getEmployeeDetailsByname(String name);
	  public boolean deleteEmployeeInfo(int id);
	  public boolean updateEmployeeInfo(Employee bean);
	  public boolean createEmployeeInfo(Employee bean);
	  public boolean addEmployeeInfo(Employee bean);
	  public List<Employee> getAllEmployeeDetails();

}
