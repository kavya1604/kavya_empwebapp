package com.capgemini.assignment.service;

public interface EmployeeService {

}
