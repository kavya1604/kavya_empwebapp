package com.capgemini.assignment.service;

import com.capgemini.assignment.dao.EmployeeDao;
import com.capgemini.assignment.dao.EmployeeDaoImpl;
import com.capgemini.assignment.dto.Employee;

public class EmployeeServiceImpl implements EmployeeService{

	private EmployeeDao dao=new EmployeeDaoImpl();

	public Employee getEmployeeDetailsByname(String name) {
		// TODO Auto-generated method stub
		return dao.getEmployeeDetailsByname(name);
}
}