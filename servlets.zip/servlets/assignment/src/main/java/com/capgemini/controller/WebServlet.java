package com.capgemini.controller;

import java.lang.annotation.Documented;

@Documented
public @interface WebServlet {

}
